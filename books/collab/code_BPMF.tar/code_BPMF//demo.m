restart=1;
fprintf(1,'Running Probabilistic Matrix Factorization (PMF) \n');
pmf

restart=1;
fprintf(1,'\nRunning Bayesian PMF\n');
bayespmf

